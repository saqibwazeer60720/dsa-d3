#include <iostream>
using namespace std;

template <typename t>
class abstractstack {
public:
    virtual void push(t value) = 0;
    virtual t pop() = 0;
    virtual t top() const = 0;
    virtual bool isempty() const = 0;
    virtual bool isfull() const = 0;
    virtual ~abstractstack() {}
};

template <typename t>
class mystack : public abstractstack<t> {
private:
    t* arr;
    int size;
    int tos;

public:
    mystack(int s) {
        size = s;
        arr = new t[size];
        tos = -1;
    }

    void push(t value) override {
        if (isfull()) {
            cout << "stack is full" << endl;
        }
        else {
            arr[++tos] = value;
            cout << "element pushed" << endl;
        }
    }

    t pop() override {
        if (isempty()) {
            cout << "stack is empty" << endl;
            return t{};
        }

        return arr[tos--];
    }

    t top() const override {
        if (isempty()) {
            cout << "stack is empty" << endl;
            return t{};
        }

        return arr[tos];
    }

    bool isempty() const override {
        return tos == -1;
    }

    bool isfull() const override {
        return tos == size - 1;
    }

    void display() const {
        if (isempty()) {
            cout << "stack is empty" << endl;
        }
        else {
            for (int i = tos; i >= 0; i--) {
                cout << arr[i] << endl;
            }
        }
    }

    ~mystack() {
        delete[] arr;
    }
};

int main() {
    int size, choice, value;

    cout << "enter stack size: ";
    cin >> size;

    if (size <= 0) {
        cout << "invalid size" << endl;
        return 0;
    }

    mystack<int> s(size);

    do {
        cout << endl;
        cout << "1. push" << endl;
        cout << "2. pop" << endl;
        cout << "3. top" << endl;
        cout << "4. isempty" << endl;
        cout << "5. isfull" << endl;
        cout << "6. display" << endl;
        cout << "0. exit" << endl;
        cout << "enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "enter value: ";
            cin >> value;
            s.push(value);
            break;

        case 2:
            if (!s.isempty()) {
                cout << "popped element: " << s.pop() << endl;
            }
            else {
                cout << "stack is empty" << endl;
            }
            break;

        case 3:
            if (!s.isempty()) {
                cout << "top element: " << s.top() << endl;
            }
            else {
                cout << "stack is empty" << endl;
            }
            break;

        case 4:
            cout << (s.isempty() ? "stack is empty" : "stack is not empty") << endl;
            break;

        case 5:
            cout << (s.isfull() ? "stack is full" : "stack is not full") << endl;
            break;

        case 6:
            s.display();
            break;

        case 0:
            cout << "program ended" << endl;
            break;

        default:
            cout << "invalid choice" << endl;
        }

    } while (choice != 0);

    return 0;
}