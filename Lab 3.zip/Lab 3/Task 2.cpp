
#include <iostream>
using namespace std;

template <class T>
class List
{
protected:
    T* arr;
    int maxSize, currentSize;

public:
    List(int m = 10, int c = 0)
    {
        maxSize = m;
        currentSize = c;
        arr = new T[maxSize];
    }

    List(const List& obj)
    {
        maxSize = obj.maxSize;
        currentSize = obj.currentSize;
        arr = new T[maxSize];

        for (int i = 0; i < currentSize; i++)
            arr[i] = obj.arr[i];
    }

    virtual void addElementAtFirstIndex(T) = 0;
    virtual void addElementAtLastIndex(T) = 0;
    virtual T removeElementFromEnd() = 0;
    virtual void removeElementFromStart() = 0;

    virtual ~List()
    {
        delete[] arr;
    }
};

template <class T>
class MyList : public List<T>
{
public:
    MyList(int m = 10, int c = 0) : List<T>(m, c) {}

    MyList(const MyList& obj) : List<T>(obj) {}

    bool empty()
    {
        return this->currentSize == 0;
    }

    bool full()
    {
        return this->currentSize == this->maxSize;
    }

    int size()
    {
        return this->currentSize;
    }

    void addElementAtFirstIndex(T value)
    {
        if (full()) return;

        for (int i = this->currentSize; i > 0; i--)
            this->arr[i] = this->arr[i - 1];

        this->arr[0] = value;
        this->currentSize++;
    }

    void addElementAtLastIndex(T value)
    {
        if (full()) return;

        this->arr[this->currentSize] = value;
        this->currentSize++;
    }

    T removeElementFromEnd()
    {
        if (empty()) return T();

        return this->arr[--this->currentSize];
    }

    void removeElementFromStart()
    {
        if (empty()) return;

        for (int i = 0; i < this->currentSize - 1; i++)
            this->arr[i] = this->arr[i + 1];

        this->currentSize--;
    }

    bool insertAt(int index, T value)
    {
        if (full() || index < 0 || index > this->currentSize)
            return false;

        for (int i = this->currentSize; i > index; i--)
            this->arr[i] = this->arr[i - 1];

        this->arr[index] = value;
        this->currentSize++;
        return true;
    }

    T last()
    {
        if (empty()) return T();

        return this->arr[this->currentSize - 1];
    }

    bool search(T value)
    {
        for (int i = 0; i < this->currentSize; i++)
            if (this->arr[i] == value)
                return true;

        return false;
    }

    void display()
    {
        for (int i = 0; i < this->currentSize; i++)
            cout << this->arr[i] << " ";

        cout << endl;
    }

    ~MyList() {}
};

int main()
{
    MyList<int> l;
    int choice, value, index;

    do
    {
        cout << "1. Add First" << endl;
        cout << "2. Add Last" << endl;
        cout << "3. Remove First" << endl;
        cout << "4. Remove Last" << endl;
        cout << "5. Insert At" << endl;
        cout << "6. Last Element" << endl;
        cout << "7. Search" << endl;
        cout << "8. Size" << endl;
        cout << "9. Empty" << endl;
        cout << "10. Full" << endl;
        cout << "11. Display" << endl;
        cout << "0. Exit" << endl;

        cout << "Enter choice: " << endl;
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value: " << endl;
            cin >> value;
            l.addElementAtFirstIndex(value);
            break;

        case 2:
            cout << "Enter value: " << endl;
            cin >> value;
            l.addElementAtLastIndex(value);
            break;

        case 3:
            l.removeElementFromStart();
            break;

        case 4:
            cout << l.removeElementFromEnd() << endl;
            break;

        case 5:
            cout << "Enter index and value: " << endl;
            cin >> index >> value;
            cout << l.insertAt(index, value) << endl;
            break;

        case 6:
            cout << l.last() << endl;
            break;

        case 7:
            cout << "Enter value: " << endl;
            cin >> value;
            cout << l.search(value) << endl;
            break;

        case 8:
            cout << l.size() << endl;
            break;

        case 9:
            cout << l.empty() << endl;
            break;

        case 10:
            cout << l.full() << endl;
            break;

        case 11:
            l.display();
            break;
        }

    } while (choice != 0);

    return 0;
}
