
#include <iostream>
using namespace std;

template <class T>
class List
{
protected:
    T* arr;
    int maxSize, currentSize;

public:
    List(int m = 10, int c = 0)
    {
        maxSize = m;
        currentSize = c;
        arr = new T[maxSize];
    }

    List(const List& obj)
    {
        maxSize = obj.maxSize;
        currentSize = obj.currentSize;
        arr = new T[maxSize];

        for (int i = 0; i < currentSize; i++)
            arr[i] = obj.arr[i];
    }

    virtual void addElementAtFirstIndex(T) = 0;
    virtual void addElementAtLastIndex(T) = 0;
    virtual T removeElementFromEnd() = 0;
    virtual void removeElementFromStart() = 0;

    virtual ~List()
    {
        delete[] arr;
    }
};

template <class T>
class MyList : public List<T>
{
public:
    MyList(int m = 10, int c = 0) : List<T>(m, c) {}

    MyList(const MyList& obj) : List<T>(obj) {}

    bool empty()
    {
        return this->currentSize == 0;
    }

    bool full()
    {
        return this->currentSize == this->maxSize;
    }

    int size()
    {
        return this->currentSize;
    }

    void addElementAtFirstIndex(T v)
    {
        if (full()) return;

        for (int i = this->currentSize; i > 0; i--)
            this->arr[i] = this->arr[i - 1];

        this->arr[0] = v;
        this->currentSize++;
    }

    void addElementAtLastIndex(T v)
    {
        if (full()) return;

        this->arr[this->currentSize++] = v;
    }

    T removeElementFromEnd()
    {
        if (empty()) return T();

        return this->arr[--this->currentSize];
    }

    void removeElementFromStart()
    {
        if (empty()) return;

        for (int i = 0; i < this->currentSize - 1; i++)
            this->arr[i] = this->arr[i + 1];

        this->currentSize--;
    }

    bool insertAt(int index, T v)
    {
        if (full() || index < 0 || index > this->currentSize)
            return false;

        for (int i = this->currentSize; i > index; i--)
            this->arr[i] = this->arr[i - 1];

        this->arr[index] = v;
        this->currentSize++;
        return true;
    }

    T last()
    {
        if (empty()) return T();
        return this->arr[this->currentSize - 1];
    }

    bool search(T v)
    {
        for (int i = 0; i < this->currentSize; i++)
            if (this->arr[i] == v)
                return true;

        return false;
    }

    void display()
    {
        for (int i = 0; i < this->currentSize; i++)
            cout << this->arr[i] << " ";

        cout << endl;
    }

    ~MyList() {}
};

template <class T>
class CustomList : public MyList<T>
{
public:
    CustomList(int m = 10, int c = 0) : MyList<T>(m, c) {}

    CustomList(const CustomList& obj) : MyList<T>(obj) {}

    T sum_ofPrime()
    {
        T sum = 0;

        for (int i = 0; i < this->currentSize; i++)
        {
            int n = this->arr[i];
            bool prime = true;

            if (n < 2) prime = false;

            for (int j = 2; j * j <= n; j++)
                if (n % j == 0)
                    prime = false;

            if (prime) sum += n;
        }

        return sum;
    }

    T secondMaxEven()
    {
        T max1 = T(), max2 = T();
        bool found1 = false, found2 = false;

        for (int i = 0; i < this->currentSize; i++)
        {
            T n = this->arr[i];

            if (n % 2 == 0)
            {
                if (!found1 || n > max1)
                {
                    max2 = max1;
                    found2 = found1;
                    max1 = n;
                    found1 = true;
                }
                else if (n < max1 && (!found2 || n > max2))
                {
                    max2 = n;
                    found2 = true;
                }
            }
        }

        if (found2) return max2;
        return T();
    }

    T secondMinOdd()
    {
        T min1 = T(), min2 = T();
        bool found1 = false, found2 = false;

        for (int i = 0; i < this->currentSize; i++)
        {
            T n = this->arr[i];

            if (n % 2 != 0)
            {
                if (!found1 || n < min1)
                {
                    min2 = min1;
                    found2 = found1;
                    min1 = n;
                    found1 = true;
                }
                else if (n > min1 && (!found2 || n < min2))
                {
                    min2 = n;
                    found2 = true;
                }
            }
        }

        if (found2) return min2;
        return T();
    }

    void printDuplicates()
    {
        for (int i = 0; i < this->currentSize; i++)
        {
            bool already = false;

            for (int k = 0; k < i; k++)
                if (this->arr[i] == this->arr[k])
                    already = true;

            if (!already)
            {
                int count = 0;

                for (int j = 0; j < this->currentSize; j++)
                    if (this->arr[i] == this->arr[j])
                        count++;

                if (count > 1)
                    cout << this->arr[i] << " ";
            }
        }

        cout << endl;
    }

    void rotateClockwaise(int r)
    {
        int n = this->currentSize;
        int mid = (n + 1) / 2;
        r = r < 0 ? 0 : r;

        for (int start = 0; start < 2; start++)
        {
            int a = (start == 0) ? 0 : mid;
            int b = (start == 0) ? mid : n;

            if (b - a <= 1) continue;

            int times = r % (b - a);

            while (times--)
            {
                T temp = this->arr[b - 1];

                for (int i = b - 1; i > a; i--)
                    this->arr[i] = this->arr[i - 1];

                this->arr[a] = temp;
            }
        }
    }

    void rotateanitclockwaise(int rt)
    {
        int n = this->currentSize;
        int mid = (n + 1) / 2;
        rt = rt < 0 ? 0 : rt;

        for (int start = 0; start < 2; start++)
        {
            int a = (start == 0) ? 0 : mid;
            int b = (start == 0) ? mid : n;

            if (b - a <= 1) continue;

            int times = rt % (b - a);

            while (times--)
            {
                T temp = this->arr[a];

                for (int i = a; i < b - 1; i++)
                    this->arr[i] = this->arr[i + 1];

                this->arr[b - 1] = temp;
            }
        }
    }

    ~CustomList() {}
};

int main()
{
    CustomList<int> l;
    int choice, value, r;

    do
    {
        cout << "1. Add Element" << endl;
        cout << "2. Display List" << endl;
        cout << "3. Sum of Prime Numbers" << endl;
        cout << "4. Second Maximum Even" << endl;
        cout << "5. Second Minimum Odd" << endl;
        cout << "6. Print Duplicates" << endl;
        cout << "7. Rotate Clockwise" << endl;
        cout << "8. Rotate Anticlockwise" << endl;
        cout << "0. Exit" << endl;

        cout << "Enter choice: " << endl;
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value: " << endl;
            cin >> value;
            l.addElementAtLastIndex(value);
            break;

        case 2:
            l.display();
            break;

        case 3:
            cout << l.sum_ofPrime() << endl;
            break;

        case 4:
            cout << l.secondMaxEven() << endl;
            break;

        case 5:
            cout << l.secondMinOdd() << endl;
            break;

        case 6:
            l.printDuplicates();
            break;

        case 7:
            cout << "Enter rotations: " << endl;
            cin >> r;
            l.rotateClockwaise(r);
            l.display();
            break;

        case 8:
            cout << "Enter rotations: " << endl;
            cin >> r;
            l.rotateanitclockwaise(r);
            l.display();
            break;

        case 0:
            cout << "Program ended" << endl;
            break;

        default:
            cout << "Invalid choice" << endl;
        }

    } while (choice != 0);

    return 0;
}
