
#include <iostream>
using namespace std;

template <class type>
class list
{
protected:
    type* arr;
    int maxsize;
    int currentsize;

public:
    list(int m = 10, int c = 0)
    {
        maxsize = m;
        currentsize = c;
        arr = new type[maxsize];
    }

    list(const list& obj)
    {
        maxsize = obj.maxsize;
        currentsize = obj.currentsize;
        arr = new type[maxsize];

        for (int i = 0; i < currentsize; i++)
            arr[i] = obj.arr[i];
    }

    virtual void addelementatfirstindex(type) = 0;
    virtual void addelementatlastindex(type) = 0;
    virtual type removeelementfromend() = 0;
    virtual void removeelementfromstart() = 0;

    virtual ~list()
    {
        delete[] arr;
    }
};

int main()
{
    return 0;
}
