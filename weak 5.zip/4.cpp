
#include <iostream>
#include <queue>
using namespace std;

class ticket {
private:
	queue<int> q;

public:
	void enqueue(int ticket_id) {
		if (ticket_id < 1000 || ticket_id > 9999) {
			cout << "invalid ticket id! enter 4 digit id." << endl;
		}
		else {
			q.push(ticket_id);
			cout << "ticket added successfully!" << endl;
		}
	}

	void dequeue() {
		if (q.empty()) {
			cout << "no pending tickets!" << endl;
		}
		else {
			cout << "ticket resolved: " << q.front() << endl;
			q.pop();
		}
	}

	void front() {
		if (q.empty()) {
			cout << "no pending tickets!" << endl;
		}
		else {
			cout << "next ticket: " << q.front() << endl;
		}
	}

	void display() {
		if (q.empty()) {
			cout << "no pending tickets!" << endl;
		}
		else {
			queue<int> temp = q;

			cout << "pending tickets: " << endl;

			while (!temp.empty()) {
				cout << temp.front() << endl;
				temp.pop();
			}
		}
	}
};

int main() {
	ticket t;
	int choice, id;

	do {
		cout << endl;
		cout << "1. add new ticket" << endl;
		cout << "2. resolve ticket" << endl;
		cout << "3. next ticket" << endl;
		cout << "4. display tickets" << endl;
		cout << "5. exit" << endl;

		cout << "enter your choice: " << endl;
		cin >> choice;

		switch (choice) {

		case 1:
			cout << "enter 4 digit ticket id: " << endl;
			cin >> id;
			t.enqueue(id);
			break;

		case 2:
			t.dequeue();
			break;

		case 3:
			t.front();
			break;

		case 4:
			t.display();
			break;

		case 5:
			cout << "program ended!" << endl;
			break;

		default:
			cout << "wrong choice!" << endl;
		}

	} while (choice != 5);

	return 0;
}
