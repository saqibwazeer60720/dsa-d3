
#include <iostream>
using namespace std;

class printer {
private:
	char q[10][100];
	int f;
	int r;

public:
	printer() {
		f = 0;
		r = -1;
	}

	bool isempty() {
		return r < f;
	}

	bool isfull() {
		return r == 9;
	}

	void enqueue(char name[]) {
		if (isfull()) {
			cout << "print queue is full!" << endl;
		}
		else {
			r++;

			int i = 0;

			while (name[i] != '\0') {
				q[r][i] = name[i];
				i++;
			}

			q[r][i] = '\0';

			cout << "print job added successfully!" << endl;
		}
	}

	void dequeue() {
		if (isempty()) {
			cout << "no print jobs available!" << endl;
		}
		else {
			cout << "printing document: " << q[f] << endl;
			f++;
			cout << "document printed successfully!" << endl;
		}
	}

	void front() {
		if (isempty()) {
			cout << "no print jobs available!" << endl;
		}
		else {
			cout << "next document: " << q[f] << endl;
		}
	}

	void display() {
		if (isempty()) {
			cout << "no print jobs available!" << endl;
		}
		else {
			cout << "pending print jobs:" << endl;

			for (int i = f; i <= r; i++) {
				cout << q[i] << endl;
			}
		}
	}
};

int main() {
	printer p;
	int choice;
	char name[100];

	do {
		cout << endl;
		cout << "1. add print job" << endl;
		cout << "2. print document" << endl;
		cout << "3. next document" << endl;
		cout << "4. display print jobs" << endl;
		cout << "5. exit" << endl;

		cout << "enter your choice: " << endl;
		cin >> choice;

		cin.ignore(1000, '\n');

		switch (choice) {

		case 1:
			cout << "enter document name: " << endl;
			cin.getline(name, 100);
			p.enqueue(name);
			break;

		case 2:
			p.dequeue();
			break;

		case 3:
			p.front();
			break;

		case 4:
			p.display();
			break;

		case 5:
			cout << "program ended!" << endl;
			break;

		default:
			cout << "wrong choice!" << endl;
		}

	} while (choice != 5);

	return 0;
}
