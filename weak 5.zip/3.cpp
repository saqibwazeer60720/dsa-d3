
#include <iostream>
#include <queue>
#include <stack>
using namespace std;

int main() {
	queue<int> q;
	stack<int> s;

	int n, value, k;

	cout << "enter number of elements: " << endl;
	cin >> n;

	for (int i = 0; i < n; i++) {
		cout << "enter value: " << endl;
		cin >> value;
		q.push(value);
	}

	cout << "enter k: " << endl;
	cin >> k;

	if (k > n) {
		k = n;
	}

	if (k > 1) {

		for (int i = 0; i < k; i++) {
			s.push(q.front());
			q.pop();
		}

		while (!s.empty()) {
			q.push(s.top());
			s.pop();
		}

		for (int i = 0; i < n - k; i++) {
			q.push(q.front());
			q.pop();
		}
	}

	cout << "queue: " << endl;

	while (!q.empty()) {
		cout << q.front() << " ";
		q.pop();
	}

	cout << endl;

	return 0;
}
