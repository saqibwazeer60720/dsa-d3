
#include <iostream>
#include <stack>
using namespace std;

class myqueue {
private:
	stack<int> s1;
	stack<int> s2;

public:
	void enqueue(int value) {
		s1.push(value);
		cout << "value inserted!" << endl;
	}

	int dequeue() {
		if (s1.empty() && s2.empty()) {
			cout << "queue is empty!" << endl;
			return -1;
		}

		if (s2.empty()) {
			while (!s1.empty()) {
				s2.push(s1.top());
				s1.pop();
			}
		}

		int value = s2.top();
		s2.pop();

		return value;
	}

	int front() {
		if (s1.empty() && s2.empty()) {
			cout << "queue is empty!" << endl;
			return -1;
		}

		if (s2.empty()) {
			while (!s1.empty()) {
				s2.push(s1.top());
				s1.pop();
			}
		}

		return s2.top();
	}

	void display() {
		if (s1.empty() && s2.empty()) {
			cout << "queue is empty!" << endl;
			return;
		}

		stack<int> temp = s2;
		stack<int> temp2;

		while (!temp.empty()) {
			temp2.push(temp.top());
			temp.pop();
		}

		while (!temp2.empty()) {
			cout << temp2.top() << endl;
			temp2.pop();
		}

		temp = s1;

		while (!temp.empty()) {
			cout << temp.top() << endl;
			temp.pop();
		}
	}
};

int main() {
	myqueue q;
	int choice, value;

	do {
		cout << "1. enqueue" << endl;
		cout << "2. dequeue" << endl;
		cout << "3. front element" << endl;
		cout << "4. display" << endl;
		cout << "5. exit" << endl;

		cout << "enter your choice: " << endl;
		cin >> choice;

		switch (choice) {
		case 1:
			cout << "enter value: " << endl;
			cin >> value;
			q.enqueue(value);
			break;

		case 2:
			value = q.dequeue();

			if (value != -1) {
				cout << "deleted value: " << value << endl;
			}
			break;

		case 3:
			value = q.front();

			if (value != -1) {
				cout << "front element: " << value << endl;
			}
			break;

		case 4:
			cout << "queue elements:" << endl;
			q.display();
			break;

		case 5:
			cout << "program ended!" << endl;
			break;

		default:
			cout << "wrong choice!" << endl;
		}

	} while (choice != 5);

	return 0;
}
