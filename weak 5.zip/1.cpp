
#include <iostream>
using namespace std;

template <typename t>
class abstractqueue {
public:
	virtual void enqueue(t value) = 0;
	virtual t dequeue() = 0;
	virtual t front() const = 0;
	virtual bool isempty() const = 0;
	virtual bool isfull() const = 0;

	virtual ~abstractqueue() {}
};

template <typename t>
class myqueue : public abstractqueue<t> {
private:
	t *arr;
	int size;
	int count;
	int f;
	int r;

public:
	myqueue(int s) {
		size = s;
		arr = new t[size];
		count = 0;
		f = 0;
		r = -1;
	}

	~myqueue() {
		delete[] arr;
	}

	bool isempty() const {
		return count == 0;
	}

	bool isfull() const {
		return count == size;
	}

	void enqueue(t value) {
		if (isfull()) {
			cout << "queue is full!" << endl;
		}
		else {
			r = (r + 1) % size;
			arr[r] = value;
			count++;
			cout << "value inserted!" << endl;
		}
	}

	t dequeue() {
		if (isempty()) {
			cout << "queue is empty!" << endl;
			return t();
		}
		else {
			t value = arr[f];
			f = (f + 1) % size;
			count--;
			return value;
		}
	}

	t front() const {
		if (isempty()) {
			cout << "queue is empty!" << endl;
			return t();
		}
		else {
			return arr[f];
		}
	}

	void display() const {
		if (isempty()) {
			cout << "queue is empty!" << endl;
		}
		else {
			cout << "queue elements:" << endl;

			for (int i = 0; i < count; i++) {
				cout << arr[(f + i) % size] << endl;
			}
		}
	}
};

int main() {
	int s, choice, value;

	cout << "enter queue size: " << endl;
	cin >> s;

	if (s <= 0) {
		cout << "invalid size!" << endl;
		return 0;
	}

	myqueue<int> q(s);

	do {
		cout << "1. enqueue" << endl;
		cout << "2. dequeue" << endl;
		cout << "3. front" << endl;
		cout << "4. isempty" << endl;
		cout << "5. isfull" << endl;
		cout << "6. display" << endl;
		cout << "7. exit" << endl;

		cout << "enter your choice: " << endl;
		cin >> choice;

		switch (choice) {
		case 1:
			cout << "enter value: " << endl;
			cin >> value;
			q.enqueue(value);
			break;

		case 2:
			if (!q.isempty()) {
				cout << "deleted value: " << q.dequeue() << endl;
			}
			else {
				cout << "queue is empty!" << endl;
			}
			break;

		case 3:
			if (!q.isempty()) {
				cout << "front value: " << q.front() << endl;
			}
			else {
				cout << "queue is empty!" << endl;
			}
			break;

		case 4:
			if (q.isempty()) {
				cout << "queue is empty!" << endl;
			}
			else {
				cout << "queue is not empty!" << endl;
			}
			break;

		case 5:
			if (q.isfull()) {
				cout << "queue is full!" << endl;
			}
			else {
				cout << "queue is not full!" << endl;
			}
			break;

		case 6:
			q.display();
			break;

		case 7:
			cout << "program ended!" << endl;
			break;

		default:
			cout << "wrong choice!" << endl;
		}

	} while (choice != 7);

	return 0;
}
